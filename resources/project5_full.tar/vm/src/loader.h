#ifndef __LOADER_H
#define __LOADER_H

extern void loader_load_file(char* file_name);

#endif // __LOADER_H
